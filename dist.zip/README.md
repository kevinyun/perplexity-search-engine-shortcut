# perplexity-search-engine-shortcut

This will set a shortcut to Perplexity AI (https://perplexity.ai) so that you can start your searches right from the Chrome omnibox, instead of having to manually navigate to Perplexity then entering in your search.



## Uploading to Google Chrome Store

Run `zip -r dist.zip *` to zip the package if you are on a Mac, then upload to Chrome Store.