# perplexity-search-engine-shortcut

Just type 'perplexity.ai' in the Chrome URL bar, press Tab, and start your search. This extension lets you start your Perplexity AI searches right from the Chrome omnibox, instead of manually having to navigate to Perplexity to start your search.



## Uploading to Google Chrome Store

Run `zip -r dist.zip *` to zip the package if you are on a Mac, then upload to Chrome Store.